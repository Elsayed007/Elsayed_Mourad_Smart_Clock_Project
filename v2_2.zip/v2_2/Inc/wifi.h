#include "main.h"

#define max1 49
#define max2 1500
#define APPID 33c2c6b47138c2ba83251eda6c71f8aa
#define forecast_length 4
#define Timezone 8

extern struct tm gmt_time;
 
typedef struct { 
	uint8_t Flag; 
	uint8_t Stratum; 
	uint8_t Poll; 
	uint8_t Precision; 
	int32_t RootDelay; 
	uint32_t RootDispersion; 
	uint32_t ReferenceId; 
	uint32_t ReferenceTimestamp[2]; 
	uint32_t OriginateTimestamp[2]; 
	uint32_t ReceiveTimestamp[2]; 
	uint32_t TransmitTimestamp[2]; 
} SNTP_HEADER_TypeDef; 


struct weathertype
{
	char main[20];
	char description[20];
	char icon[9];
	char temp[9];
	//char pressure[10];
	char humidity[9];
	//char temp_min[9];
//	char temp_max[9];
//	char visibility[10];
	char wind_speed[9];
	char wind_degree[9];
//	char clouds[9];
//	char dt[9];
//	char sys[9];
//	char type[9];
//	char id[10];
	char country[9];
//	char sunrise[9];
//	char sunset[9];
//	char timezone[9];
//	char city_id[9];
	char city_name[20];
	char dt_txt[20];
};

//struct weathertype current_weather;
	
extern struct weathertype forecast_weather[forecast_length];

extern uint32_t Transmit_Timestamp;
extern uint8_t rx_string1[max1];	//receive buffer for Timestamp
extern uint8_t rx_string2[max2];
extern uint8_t rx_timestamp[max1];

void Error_Handler(void);
void Wifi_Uart_Time(const char*, int); //UART communication with Wifi-Module
void Wifi_Uart_Weather(const char*, int); //UART communication with Wifi-Module
void Wifi_ATCommands(void);				//initialising Wifi-Module


void SetTimeServerURL(const char*); //sets the URL & protocols for Time server
void SetWeatherServerURL(const char*); //sets the URL & protocols for Weather server

void SetGMT_to_Local(void);						
void looking_for_Date (uint32_t);
void GetTime(void);


void GetWeather(void);
void ConvertWeather(char*);

//extern RTC_HandleTypeDef hrtc;

extern UART_HandleTypeDef huart1;
//extern UART_HandleTypeDef huart2;


extern const char* weather_server_URL;
extern const char* time_server_URL0;
extern const char* time_server_URL1;
extern const char* time_server_URL2;
extern const char* time_server_URL3;
extern const char* time_server_URL4;



extern uint8_t receive_mode;


