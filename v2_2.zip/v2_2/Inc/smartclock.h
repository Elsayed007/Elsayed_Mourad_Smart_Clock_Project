//Letzte �nderung 17.12.2019 09:10

#include "main.h"

/*Defines*/

#define TRUE 1
#define FALSE 0

//Bit Positionen

#define Bit0 (1<<0)
#define Bit1 (1<<1)
#define	Bit2 (1<<2)
#define Bit3 (1<<3)
#define Bit4 (1<<4)
#define Bit5 (1<<5)
#define Bit6 (1<<6)
#define Bit7 (1<<7)





//Matrix Dimensionen

#define BW_ROWS 24
#define BW_COMS 8

#define RGB_ROWS 24
#define RGB_COMS 8





//HT1632-Chip Select

#define HT1632_CS_BW 0
#define HT1632_CS_RGB 1

//HT1632-IDs

#define CMD 	4
#define WRITE 5
#define READ 	6

//HT1632-COMMANDs

#define SYS_DIS 0
#define SYS_EN 	1

#define LED_OFF 2
#define LED_ON 	3

#define BLINK_OFF 8
#define BLINK_ON 	9

#define SLV_MODE 		16
#define RC_MODE 		24
#define EXTCLK_MODE 28

#define COM_N8				32		
#define COM_N16 			36		
#define COM_P8				40		
#define COM_P16 			44		

#define PWM_1 				160		
#define PWM_2 				161
#define PWM_3 				162		
#define PWM_4					163		
#define PWM_5 				164		
#define PWM_6 				165		
#define PWM_7					166		
#define PWM_8 				167		
#define PWM_9 				168		
#define PWM_10 				169		
#define PWM_11 				170		
#define PWM_12 				171		
#define PWM_13 				172		
#define PWM_14 				173		
#define PWM_15 				174		
#define PWM_16 				175		

//HT1632-Bitorder Directions

#define LSB 0
#define MSB 1

//HT1632-Data Size

#define FULL 7
#define HALF 3

//HT1632-Shift Directions

#define UP 1
#define DOWN 2
#define LEFT 3
#define RIGHT 4

#define SFT 5
#define SPC 6
#define CORR 7

#define SET 8
#define WAIT 0
#define CNT 9

//HT1632-Fin Flags

#define FIN_CHAR 1
#define FIN_STRING 2

//HT1632-Alignment

#define ALIGN_MID 1
#define ALIGN_LEFT 2
#define ALIGN_RIGHT 3

//HT1632-Spaces

#define SPACE_BETWEEN_CHARACTERS 1
#define SPACE_BETWEEN_NUMBERS 1

//HT1632-Wait Times

#define WAIT_INTERLUDE 10
#define WAIT_TEMPHUM 5
#define WAIT_WEEKDAY 2
#define WAIT_DAYMONTH 50

//HT1632-Points

#define POINTS 235

//HT1632-RGB Farben

#define RED (1<<0)
#define GREEN (1<<1)
#define BLUE (1<<2)
#define WHITE (RED|GREEN|BLUE)
#define BLACK ~WHITE
#define ORANGE (RED|GREEN)
#define PURPLE (RED|BLUE)
#define YELLOW (GREEN|BLUE)


//Smart Clock Modi

#define MODE_TIME 1
#define MODE_DATE 2
#define MODE_TEMP 3
#define MODE_HUM 4
#define MODE_TEMPHUM 5
#define MODE_WEATHER 6
#define MODE_TIMER 7
#define MODE_STOPWATCH 8
#define MODE_ALARM 9
#define MODE_ALARM_IT 10


#define ROT 1
#define GRUEN 2
#define BLAU 3


//DS3231

#define DS3231 0xD0

#define MON 1
#define TUE 2
#define WED 3
#define THU 4
#define FRI 5
#define SAT 6
#define SUN 7


#define JAN 1
#define FEB 2
#define MAR 3
#define APR 4
#define MAY 5
#define JUN 6
#define JUL 7
#define AUG 8
#define SEP 9
#define OCT 10
#define NOV 11
#define DEC 12

#define HF12 1 	// 12 Hours Format
#define HF24 0	// 24 Hours Format

#define AM 0
#define PM 1


/*Variablen*/









extern uint8_t MODE;	//Smart Clock Modi 
extern uint8_t INTERLUDE; // Zwischensequenz
extern uint8_t RST;		//Umschalten Reset
extern uint8_t SWITCH;

extern uint8_t B_PLUS;
extern uint8_t B_SET;



extern uint8_t ASCII[128][9];		//ASCII Tabelle
extern uint8_t NUMBERS[10][9];	//Nummern Tabelle

extern char WEEKDAYS[7][4];	//Wochentage
extern char MONTHS[12][4];	//Monate

extern uint8_t RGB_PATTERN[8][RGB_COMS][RGB_ROWS/3];

extern uint8_t HT1632_MEM_BW[BW_ROWS];		//Memory BW Matrizen
extern uint8_t HT1632_MEM_RGB[RGB_ROWS];	//Memory RGB Matrizen

extern uint8_t SECONDS; //Sekunden
extern uint8_t HOURS;	//Stunden
extern uint8_t MINUTES;	//Minuten

extern uint8_t DAY;	//Wochentag - 1
extern uint8_t DATE;	//Datumstag - 0
extern uint8_t MONTH;	//Monat - 1

extern float TEMPERATURE; //Temperatur
extern float HUMIDITY;	//Luftfeuchtigkeit

extern uint8_t Tilt1;	//Neigung 1
extern uint8_t Tilt2;	//Neigung 2

typedef struct
{
	I2C_HandleTypeDef *AM2320_Handle;
	uint8_t addr;
	uint8_t data[8];
}AM2320;
extern uint8_t Registers[3]; //Temperatursensor Initialisierung


typedef struct
{
	uint8_t Seconds;
	uint8_t Minutes;
	uint8_t Hours;
	uint8_t TimeFormat;
	uint8_t AM_PM;
}DS3231_TIME;


typedef struct
{
	uint8_t Day;
	uint8_t Date;
	uint8_t Month;
	uint8_t Year;
	uint8_t Century;
}DS3231_DATE;

typedef struct
{
	uint8_t Seconds;
	uint8_t Minutes;
	uint8_t Hours;
	uint8_t AlarmMask;
	uint8_t AM_PM;
	uint8_t TimeFormat;
	uint8_t Day;
	uint8_t Date;
	uint8_t DY_DT;
}DS3231_ALARM;

typedef struct
{
	uint8_t TimeSeconds;
	uint8_t TimeMinutes;
	uint8_t TimeHours;
	uint8_t TimeFormat;
	uint8_t TimeAmPm;
	
	uint8_t DateDay;
	uint8_t DateDate;
	uint8_t DateMonth;
	uint8_t DateCentury;
	uint8_t DateYear;
	
	uint8_t Alarm1Seconds;
	uint8_t Alarm1Minutes;
	uint8_t Alarm1Hours;
	uint8_t Alarm1Format;
	uint8_t Alarm1AmPm;
	uint8_t Alarm1Day;
	uint8_t Alarm1Date;
	uint8_t Alarm1DyDt;
	uint8_t Alarm1Mask; //0x0F A1M1 -> (1<<0)
	
	uint8_t Alarm2Minutes;
	uint8_t Alarm2Hours;
	uint8_t Alarm2Format;
	uint8_t Alarm2AmPm;
	uint8_t Alarm2Day;
	uint8_t Alarm2Date;
	uint8_t Alarm2DyDt;
	uint8_t Alarm2Mask; //0x0F A2M2 -> (1<<1)
	
	uint8_t Control;
	uint8_t ControlStatus;
	uint8_t AgingOffset;
	uint8_t MsbOfTemp;
	uint8_t LsbOfTemp;
}DS3231_REGISTERS;

typedef struct
{
	int8_t mx;
	int8_t xm;
	int8_t sx;
	int8_t xs;
	int8_t Status;
}TIME_TIMER_STOPWATCH;

extern TIME_TIMER_STOPWATCH TIMER;
extern TIME_TIMER_STOPWATCH STOPWATCH;
extern DS3231_ALARM ALARM1;
extern DS3231_ALARM ALARM2;
extern uint8_t TIMER_POS;
extern uint8_t ALARM_POS;
extern uint8_t ALARM_ST;
extern uint8_t TICK;
/*Funktionen*/

//HT1632

extern void HT1632_ChipSelect(uint8_t Chip);
extern void HT1632_ChipUnSelect(uint8_t Chip);
extern void HT1632_SendId(uint8_t Id);
extern void HT1632_SendAddr(uint8_t Addr);
extern void HT1632_SendCmdSingle(uint8_t Chip, uint8_t Cmd);
extern void HT1632_SendCmdMultiple(uint8_t Chip, uint8_t *Cmd, uint8_t Count);
extern void HT1632_SendDataSingle(uint8_t Chip, uint8_t Addr, uint8_t Data, uint8_t Size, uint8_t Dir);
extern void HT1632_SendDataMultiple(uint8_t Chip, uint8_t Addr, uint8_t *Data, uint8_t Size, uint8_t Dir, uint8_t LeftEdge, uint8_t RightEdge, uint8_t Count);

//HT1632-BW

extern void HT1632_BW_Init(void);
extern void HT1632_BW_Shift(uint8_t *Dst, uint8_t *DataIn, uint8_t *DataOut, uint8_t LeftEdge, uint8_t RightEdge, uint8_t Dir);
extern uint8_t HT1632_BW_String(uint8_t *Dst, char *String,	uint8_t *Space, uint8_t *CharPos, uint8_t *StringPos, uint8_t LeftEdge, uint8_t RightEdge, uint8_t Align);

extern void HT1632_BW_Time(uint8_t *Dst, uint8_t Hours, uint8_t Minutes, uint8_t Skip);
extern void HT1632_BW_TimePoints(uint8_t *Dst, uint8_t POINTS_ON);

extern uint8_t HT1632_BW_Date(uint8_t *Dst, uint8_t *GoTo, uint8_t *Next, uint8_t *Dir, uint8_t* Count, uint8_t *CharPos, uint8_t *StringPos, uint8_t *Mask, uint8_t *Step, uint8_t Rst, uint8_t CpltRst);
extern uint8_t HT1632_BW_TempHum(uint8_t *Dst, uint8_t *GoTo, uint8_t *Next, uint8_t *Dir, uint8_t *Count, uint8_t *Space, uint8_t *FrontPos, uint8_t *CharPos, uint8_t *StringPos, uint8_t *Mask, uint8_t *Step, uint8_t Rst, uint8_t CpltRst);


//HT1632-RGB

extern void HT1632_RGB_Init(void);
extern void HT1632_RGB_Pattern(uint8_t *Dst, uint8_t Src[][RGB_COMS][RGB_ROWS/3],uint8_t Pattern);

//Sonstiges

extern void HT1632_ClearMemory(uint8_t *Mem, uint8_t LeftEdge, uint8_t RightEdge);
extern void HT1632_SetOutput(uint8_t Chip, uint8_t *Src, uint8_t Tilt1, uint8_t Tilt2, uint8_t LeftEdge, uint8_t RightEdge);

extern uint16_t STRING_GetLength(char *String, uint8_t Space);
extern uint8_t STRING_GetData(uint8_t *DataIn, char *String, uint8_t *StringPos, uint8_t *CharPos, uint8_t *Mask, uint8_t LeftEdge, uint8_t RightEdge, uint8_t Align, uint8_t Dir);

//AM2320

extern AM2320 AM2320_Init(I2C_HandleTypeDef *I2C_Handle, uint8_t device_addr);
extern HAL_StatusTypeDef AM2320_ReadValue(AM2320 *Handle);
extern HAL_StatusTypeDef AM2320_GetValue(AM2320 *Handle,float *temp,float *hum);


////M54564FP

//extern void M54564FP_Init(void);
//extern void M54564FP_SetCom(uint8_t Com);

////DM163

//extern void DM163_Init(void);
//extern void DM163_SetGrayscaleBank0(void);

////RGB

//extern void RGB_SetPixel(uint8_t Com, uint8_t Row, uint8_t Colour);


//DS3231

extern HAL_StatusTypeDef DS3231_SetTime(DS3231_TIME Time, I2C_HandleTypeDef * I2C_Handle);
extern HAL_StatusTypeDef DS3231_GetTime(DS3231_TIME *Time, I2C_HandleTypeDef * I2C_Handle);

extern HAL_StatusTypeDef DS3231_SetDate(DS3231_DATE Date, I2C_HandleTypeDef * I2C_Handle);
extern HAL_StatusTypeDef DS3231_GetDate(DS3231_DATE *Date, I2C_HandleTypeDef * I2C_Handle);

extern HAL_StatusTypeDef DS3231_SetAlarm1(DS3231_ALARM Alarm, I2C_HandleTypeDef * I2C_Handle);
extern HAL_StatusTypeDef DS3231_GetAlarm1(DS3231_ALARM *Alarm, I2C_HandleTypeDef * I2C_Handle);

extern HAL_StatusTypeDef DS3231_SetAlarm2(DS3231_ALARM Alarm, I2C_HandleTypeDef * I2C_Handle);
extern HAL_StatusTypeDef DS3231_GetAlarm2(DS3231_ALARM *Alarm, I2C_HandleTypeDef * I2C_Handle);


extern HAL_StatusTypeDef DS3231_GetAll(DS3231_REGISTERS *Registers, I2C_HandleTypeDef * I2C_Handle);
//Sonstiges

extern uint8_t DS3231_DecToBcd(uint8_t Dec);


extern uint8_t DS3231_BcdToDec(uint8_t Bcd);

extern float GetMin(char Array[][4], uint8_t Len, uint8_t Idx);
extern float GetMax(char Array[][4], uint8_t Len, uint8_t Idx);


extern void RGB_Test(void);


